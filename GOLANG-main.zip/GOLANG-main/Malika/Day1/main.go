package main

import "fmt"

func main() {
	fmt.Println("Day1 : Learning GO Lang")
}
