package main

import (
	"fmt"
	a "new/one"
)

func main() {
	num := 5
	fmt.Printf("Factorial of %d is %d", num, a.FactR(num))
}
