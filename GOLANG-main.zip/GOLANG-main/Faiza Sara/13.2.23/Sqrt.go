package main

import (
	"fmt"
	"math"
)

func main() {
	var a float64
	fmt.Scan(&a)
	fmt.Print(math.Sqrt(a))
}
