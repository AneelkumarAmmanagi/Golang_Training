// write a code to declare a variable and print that variable

package main

import "fmt"

func main() {
	var card1 string = "Ace of spades"
	fmt.Println(card1)

	card2 := "Ace of Spades"
	card2 = "Five of Diamonds"
	fmt.Println(card2)
}
