// write a program for print a string 

package main //package declaration

import "fmt" //import other packages that we need

// declare function by using func keyword
func main() {
	fmt.Println("hello world !!")
}
