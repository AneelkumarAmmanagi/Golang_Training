package main

func main() {
	average()
	leap()

}
