package main

func main() {
	greatest_num()
	swap_num()
}
