package main

import (
	"fmt"
	o "new/first"
)

func main() {
	fmt.Println("hello its main package")
	o.Call()
}
