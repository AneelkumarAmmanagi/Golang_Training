package main

import "fmt"

func main() {
	var name = "Navneeth Prasanth"
	fmt.Printf("Hello %s !\n", name)
	Lang()
}
