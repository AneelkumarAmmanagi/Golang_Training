package main

import "fmt"

func Lang() {
	var Language = "golang"
	fmt.Printf("I am learning %s.\n", Language)
}
