package main

import "fmt"

const PI = 3.14

func main() {
	fmt.Println(PI)
}
