package main

import "fmt"

func main() {
	var a = 10
	if a%2 == 0 {
		fmt.Println(a, "is even number")
	} else {
		fmt.Println("a is odd number")
	}

}
