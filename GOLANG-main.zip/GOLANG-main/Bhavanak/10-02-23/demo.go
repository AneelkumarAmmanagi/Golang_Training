package main

import "fmt"

func main() {
	var var1 int = 90
	fmt.Println(var1)
}
