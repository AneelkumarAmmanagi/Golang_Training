package main

import "fmt"

func main() {
	fmt.Println("hi")
	fmt.Println("its kavita")
}
