package main

import "fmt"

//Declaration and initialization
const number int = 365
const pi = 3.14159
const b  = true
const name = "Harry Kane"

//Main function 
func main(){

	fmt.Println("Number is initialized as ",number)
	fmt.Println("Pi is initialized as ",pi)
	fmt.Println("b is initialized as ",b)
	fmt.Println("name is initialized as ",name)
}