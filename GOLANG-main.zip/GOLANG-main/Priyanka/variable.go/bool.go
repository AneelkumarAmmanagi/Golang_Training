package main

import "fmt"

func main() {

	var var1 bool = true
	fmt.Printf("type of var1: %T", var1)

}
