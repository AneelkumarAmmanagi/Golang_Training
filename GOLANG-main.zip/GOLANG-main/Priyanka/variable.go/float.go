package main

import "fmt"

var b float64

func main() {

	b = 201.3
	fmt.Println(b)
}
