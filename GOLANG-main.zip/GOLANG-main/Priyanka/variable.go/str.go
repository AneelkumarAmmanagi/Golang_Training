package main

import "fmt"

func main() {

	var message1 = "HI"
	message2 := "INFOBELL TEAM"
	fmt.Println(message1)
	fmt.Println(message2)
}
