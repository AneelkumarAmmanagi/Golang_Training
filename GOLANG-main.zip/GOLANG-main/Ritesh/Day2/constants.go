package main

import (
	"fmt"
)

const E int = 20
const F bool = false
const G string = "You are doing great"
const H float64 = -9898912892.8768768

// Declaring the constants "E,F,G,H and assigning values to the constants"
func cons() {
	fmt.Println(E) //Printing the assigned value for the variable "E"
	fmt.Println(F) //Printing the assigned value for the variable "F"
	fmt.Println(G) //Printing the assigned value for the variable "G"
	fmt.Println(H) //Printing the assigned value for the variable "H"

}
