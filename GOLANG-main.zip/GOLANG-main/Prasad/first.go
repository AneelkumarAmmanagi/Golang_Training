package main

import "fmt"

func main() {
	var a int = 20
	if a%2 == 0 {
		fmt.Println("Even Number")
	} else {
		fmt.Println("Odd Number")
	}
}
