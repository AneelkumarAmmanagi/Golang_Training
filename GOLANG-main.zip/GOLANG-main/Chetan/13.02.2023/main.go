  package main

// import "fmt"

func main() {

	cards := newDeck()
	cards.print()
}

// func new1Card() string {
// 	return "ace of space"
// }
