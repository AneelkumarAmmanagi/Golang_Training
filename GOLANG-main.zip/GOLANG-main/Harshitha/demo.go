package main

import "fmt"

func main() {
	var a int = 9
	var b int = 90
	c := a + b
	fmt.Println(c)
	d := b - a
	fmt.Println(d)
	e := a * b
	fmt.Println(e)
	f := a % b
	fmt.Println(f)
}
