package first

import "fmt"

func Call() {
	fmt.Println("its a call function from first package")
}
