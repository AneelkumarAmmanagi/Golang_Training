package main

import "fmt"

var a int = 6
var b float64 = 95.00
var c bool = true
var d string = "nithin"

func main() {

	fmt.Printf("%d\n", a)
	fmt.Printf("%f\n", b)
	fmt.Printf("%t\n", c)
	fmt.Printf("%s\n", d)
}
