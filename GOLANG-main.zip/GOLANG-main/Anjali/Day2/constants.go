package main

import "fmt"

func main() {
	const myConst int = 42
	fmt.Println("The value of my constant is:", myConst)
	// print the value of int
}
