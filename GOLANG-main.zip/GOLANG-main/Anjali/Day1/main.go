package main

import "fmt"

func main() {

	fmt.Println("Welcome to Learning GO Programming Language")
	fmt.Println()
	fmt.Println("Day1 : Agenda")
	fmt.Println("Introduction to Go")
	fmt.Println("Setting up the Development Environment")
	fmt.Println("Go Syntax and Basic Structure")
	fmt.Println("Writing first program in Go")
	fmt.Println("Exercise and Learning Outcome")

}
