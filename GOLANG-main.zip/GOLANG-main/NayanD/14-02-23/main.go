package main

import "fmt"

func main() {
	swap()
	fmt.Println(reverseNumber(456))
	fmt.Println(reverseNumber(123))

}
