package main

func main() {
	// leap year function
	leap_year()
	// palindrome function
	palindrome()
}
