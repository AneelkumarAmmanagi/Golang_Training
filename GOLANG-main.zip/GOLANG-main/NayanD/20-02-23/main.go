package main

import (
	a "example/first"
	b "example/second"
	"fmt"
)

func main() {
	a.Pattern()
	fmt.Println()
	b.Pattern2()
}
