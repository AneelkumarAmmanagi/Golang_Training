package main

import (
   a "new/first"
)
//to find counts of pair in array whose sum is equal to given value
func main() {
	arr :=[]int{1,5,8,2,4,9,5,1,5}
	sum :=6
	a.GetCountOfPair(arr,sum)
}
